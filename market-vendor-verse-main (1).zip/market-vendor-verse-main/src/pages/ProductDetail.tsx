import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Header } from '@/components/layout/Header';
import { CategoryNav } from '@/components/layout/CategoryNav';
import { ProductCard } from '@/components/product/ProductCard';
import { supabase } from '@/integrations/supabase/client';
import { useCart } from '@/contexts/CartContext';
import { useWishlist } from '@/hooks/useWishlist';
import { Heart, ShoppingCart, Star, Package, ArrowLeft, Minus, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RelatedProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  compare_price?: number;
  images: string[];
  stock_quantity: number;
  featured: boolean;
  vendor: {
    business_name: string;
  };
  category: {
    id: string;
    name: string;
    slug: string;
  };
}

interface Product {
  id: string;
  name: string;
  description: string;
  short_description?: string;
  price: number;
  compare_price?: number;
  images: string[];
  stock_quantity: number;
  sku?: string;
  weight?: number;
  dimensions?: any;
  tags?: string[];
  featured: boolean;
  vendor: {
    id: string;
    business_name: string;
    business_description?: string;
  };
  category: {
    id: string;
    name: string;
    slug: string;
  };
}

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<RelatedProduct[]>([]);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  useEffect(() => {
    if (id) {
      fetchProduct();
    }
  }, [id]);

  const fetchProduct = async () => {
    if (!id) return;
    
    setLoading(true);
    try {
      // Fetch product details
      const { data: productData, error: productError } = await supabase
        .from('products')
        .select(`
          *,
          vendor:vendors(id, business_name, business_description),
          category:categories(id, name, slug)
        `)
        .eq('id', id)
        .eq('is_active', true)
        .single();

      if (productError) throw productError;
      setProduct(productData);

      // Fetch related products
      const { data: relatedData } = await supabase
        .from('products')
        .select(`
          id,
          name,
          description,
          price,
          compare_price,
          images,
          stock_quantity,
          featured,
          vendor:vendors(business_name),
          category:categories(id, name, slug)
        `)
        .eq('category_id', productData.category.id)
        .eq('is_active', true)
        .neq('id', id)
        .limit(4);

      setRelatedProducts(relatedData || []);
    } catch (error) {
      console.error('Error fetching product:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (product) {
      await addToCart(product.id, quantity);
    }
  };

  const handleToggleWishlist = async () => {
    if (product) {
      await toggleWishlist(product.id);
    }
  };

  const discount = product?.compare_price ? 
    Math.round(((product.compare_price - product.price) / product.compare_price) * 100) : 0;

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <CategoryNav />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="h-96 bg-muted rounded-lg"></div>
              <div className="space-y-4">
                <div className="h-8 bg-muted rounded w-3/4"></div>
                <div className="h-6 bg-muted rounded w-1/2"></div>
                <div className="h-4 bg-muted rounded w-full"></div>
                <div className="h-4 bg-muted rounded w-2/3"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <CategoryNav />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h1 className="text-2xl font-bold mb-2">Product not found</h1>
            <p className="text-muted-foreground mb-4">The product you're looking for doesn't exist.</p>
            <Button asChild>
              <Link to="/categories">Browse Categories</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <CategoryNav />
      
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link to="/categories" className="hover:text-primary">Categories</Link>
          <span>/</span>
          <Link to={`/category/${product.category.slug}`} className="hover:text-primary">
            {product.category.name}
          </Link>
          <span>/</span>
          <span className="text-foreground">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square bg-muted rounded-lg overflow-hidden">
              {product.images?.[selectedImage] ? (
                <img 
                  src={product.images[selectedImage]} 
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="h-24 w-24 text-muted-foreground" />
                </div>
              )}
            </div>
            
            {product.images && product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={cn(
                      "flex-shrink-0 w-20 h-20 rounded-md overflow-hidden border-2 transition-colors",
                      selectedImage === index ? "border-primary" : "border-transparent"
                    )}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-start justify-between mb-2">
                <h1 className="text-3xl font-bold">{product.name}</h1>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleToggleWishlist}
                  className="text-muted-foreground hover:text-red-500"
                >
                  <Heart 
                    className={cn(
                      "h-6 w-6",
                      isInWishlist(product.id) ? "fill-red-500 text-red-500" : ""
                    )} 
                  />
                </Button>
              </div>
              
              {product.short_description && (
                <p className="text-lg text-muted-foreground">{product.short_description}</p>
              )}
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold text-primary">${product.price}</span>
                {product.compare_price && product.compare_price > product.price && (
                  <span className="text-xl text-muted-foreground line-through">
                    ${product.compare_price}
                  </span>
                )}
              </div>
              {discount > 0 && (
                <Badge variant="destructive">-{discount}% OFF</Badge>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Vendor:</span>
                <Badge variant="outline">{product.vendor.business_name}</Badge>
              </div>
              
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Stock:</span>
                <span className={cn(
                  "text-sm",
                  product.stock_quantity > 0 ? "text-green-600" : "text-red-600"
                )}>
                  {product.stock_quantity > 0 ? `${product.stock_quantity} available` : 'Out of stock'}
                </span>
              </div>

              {product.sku && (
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">SKU:</span>
                  <span className="text-sm text-muted-foreground">{product.sku}</span>
                </div>
              )}
            </div>

            {product.stock_quantity > 0 && (
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <span className="text-sm font-medium">Quantity:</span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-16 text-center font-medium">{quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))}
                      disabled={quantity >= product.stock_quantity}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <Button size="lg" className="w-full" onClick={handleAddToCart}>
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Add to Cart
                </Button>
              </div>
            )}

            {product.tags && product.tags.length > 0 && (
              <div>
                <span className="text-sm font-medium mb-2 block">Tags:</span>
                <div className="flex flex-wrap gap-2">
                  {product.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">{tag}</Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Product Details Tabs */}
        <Tabs defaultValue="description" className="mb-12">
          <TabsList>
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="vendor">Vendor Info</TabsTrigger>
          </TabsList>
          
          <TabsContent value="description" className="mt-6">
            <div className="prose max-w-none">
              {product.description ? (
                <p className="text-muted-foreground leading-relaxed">{product.description}</p>
              ) : (
                <p className="text-muted-foreground">No description available.</p>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="specifications" className="mt-6">
            <div className="space-y-4">
              {product.weight && (
                <div className="flex justify-between py-2 border-b">
                  <span className="font-medium">Weight</span>
                  <span>{product.weight} lbs</span>
                </div>
              )}
              {product.dimensions && (
                <div className="flex justify-between py-2 border-b">
                  <span className="font-medium">Dimensions</span>
                  <span>{JSON.stringify(product.dimensions)}</span>
                </div>
              )}
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">Stock Quantity</span>
                <span>{product.stock_quantity}</span>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="vendor" className="mt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">{product.vendor.business_name}</h3>
              {product.vendor.business_description && (
                <p className="text-muted-foreground">{product.vendor.business_description}</p>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Related Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;