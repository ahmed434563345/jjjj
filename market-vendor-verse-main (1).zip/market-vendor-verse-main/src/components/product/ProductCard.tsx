import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingCart, Package, Star } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useWishlist } from '@/hooks/useWishlist';
import { cn } from '@/lib/utils';

interface Product {
  id: string;
  name: string;
  price: number;
  compare_price?: number;
  images: string[];
  vendor?: {
    business_name: string;
  };
  featured?: boolean;
  stock_quantity: number;
}

interface ProductCardProps {
  product: Product;
  className?: string;
}

export function ProductCard({ product, className }: ProductCardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsLoading(true);
    await addToCart(product.id);
    setIsLoading(false);
  };

  const handleToggleWishlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    await toggleWishlist(product.id);
  };

  const discount = product.compare_price ? 
    Math.round(((product.compare_price - product.price) / product.compare_price) * 100) : 0;

  return (
    <Card className={cn("group hover:shadow-lg transition-all duration-300 overflow-hidden", className)}>
      <Link to={`/product/${product.id}`} className="block">
        <div className="relative h-48 bg-muted overflow-hidden">
          {product.images?.[0] ? (
            <img 
              src={product.images[0]} 
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Package className="h-16 w-16 text-muted-foreground" />
            </div>
          )}
          
          {/* Wishlist button */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 h-8 w-8 bg-background/80 hover:bg-background"
            onClick={handleToggleWishlist}
          >
            <Heart 
              className={cn(
                "h-4 w-4 transition-colors",
                isInWishlist(product.id) ? "fill-red-500 text-red-500" : "text-muted-foreground"
              )} 
            />
          </Button>

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {product.featured && (
              <Badge variant="secondary" className="text-xs">
                <Star className="h-3 w-3 mr-1" />
                Featured
              </Badge>
            )}
            {discount > 0 && (
              <Badge variant="destructive" className="text-xs">
                -{discount}%
              </Badge>
            )}
            {product.stock_quantity <= 5 && product.stock_quantity > 0 && (
              <Badge variant="outline" className="text-xs bg-background/80">
                Only {product.stock_quantity} left
              </Badge>
            )}
            {product.stock_quantity === 0 && (
              <Badge variant="secondary" className="text-xs bg-background/80">
                Out of Stock
              </Badge>
            )}
          </div>
        </div>

        <CardContent className="p-4">
          <h3 className="font-semibold line-clamp-2 mb-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>
          
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-primary">
                ${product.price}
              </span>
              {product.compare_price && product.compare_price > product.price && (
                <span className="text-sm text-muted-foreground line-through">
                  ${product.compare_price}
                </span>
              )}
            </div>
            {product.vendor?.business_name && (
              <Badge variant="outline" className="text-xs">
                {product.vendor.business_name}
              </Badge>
            )}
          </div>

          <Button 
            size="sm" 
            className="w-full" 
            onClick={handleAddToCart}
            disabled={isLoading || product.stock_quantity === 0}
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            {isLoading ? 'Adding...' : product.stock_quantity === 0 ? 'Out of Stock' : 'Add to Cart'}
          </Button>
        </CardContent>
      </Link>
    </Card>
  );
}