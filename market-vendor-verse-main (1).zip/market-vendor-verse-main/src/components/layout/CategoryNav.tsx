import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
}

export function CategoryNav() {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase
        .from('categories')
        .select('id, name, slug, description')
        .eq('is_active', true)
        .is('parent_id', null)
        .order('sort_order');
      
      if (data) {
        setCategories(data);
      }
    };

    fetchCategories();
  }, []);

  return (
    <nav className="border-b bg-muted/10">
      <div className="container px-4">
        <div className="flex h-12 items-center space-x-8 overflow-x-auto">
          <Link
            to="/categories"
            className="whitespace-nowrap text-sm font-medium hover:text-primary transition-colors"
          >
            All Categories
          </Link>
          {categories.map((category) => (
            <Link
              key={category.id}
              to={`/category/${category.slug}`}
              className="whitespace-nowrap text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
            >
              {category.name}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}