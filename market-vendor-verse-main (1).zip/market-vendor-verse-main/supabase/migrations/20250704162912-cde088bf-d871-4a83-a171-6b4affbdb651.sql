-- Create wishlist table
CREATE TABLE public.wishlists (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, product_id)
);

-- Enable RLS
ALTER TABLE public.wishlists ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage their own wishlist" 
ON public.wishlists 
FOR ALL 
USING (auth.uid() = user_id);

-- Add some sample categories
INSERT INTO public.categories (name, slug, description, is_active) VALUES
('Electronics', 'electronics', 'Computers, phones, gadgets and electronic accessories', true),
('Clothing', 'clothing', 'Fashion and apparel for men, women and children', true),
('Home & Garden', 'home-garden', 'Furniture, decor, gardening tools and home improvement', true),
('Sports & Fitness', 'sports-fitness', 'Exercise equipment, sportswear and outdoor gear', true),
('Books & Media', 'books-media', 'Books, movies, music and digital media', true);

-- Add some sample products
INSERT INTO public.products (name, description, price, category_id, vendor_id, stock_quantity, featured, is_active) 
SELECT 
  'Sample Product ' || generate_series(1, 20),
  'This is a sample product description that showcases the features and benefits of this amazing item.',
  (random() * 500 + 50)::decimal(10,2),
  (SELECT id FROM categories WHERE slug = 'electronics' LIMIT 1),
  (SELECT id FROM vendors LIMIT 1),
  (random() * 100 + 10)::integer,
  (random() > 0.8),
  true
WHERE EXISTS (SELECT 1 FROM vendors LIMIT 1);